CREATE DATABASE  IF NOT EXISTS `gorozeroium_dh` /*!40100 DEFAULT CHARACTER SET utf8mb3 */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `gorozeroium_dh`;
-- MySQL dump 10.13  Distrib 8.0.32, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: gorozeroium_dh
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product` (
  `id` int NOT NULL AUTO_INCREMENT,
  `product_type_id` int NOT NULL,
  `name` varchar(45) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `type` varchar(45) DEFAULT NULL,
  `image` varchar(100) DEFAULT NULL,
  `description` varchar(1000) DEFAULT NULL,
  `rating` tinyint(1) DEFAULT NULL,
  `abv` decimal(10,2) DEFAULT NULL,
  `ibu` decimal(10,2) DEFAULT NULL,
  `type_glass` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_produto_product_type1_idx` (`product_type_id`),
  CONSTRAINT `fk_produto_product_type1` FOREIGN KEY (`product_type_id`) REFERENCES `product_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product`
--

LOCK TABLES `product` WRITE;
/*!40000 ALTER TABLE `product` DISABLE KEYS */;
INSERT INTO `product` VALUES (1,1,'American Pale Ale',28.00,NULL,'american pale ale.png','A cerveja Pale Ale tem um teor alcoólico geralmente entre 4% a 6% ABV e um corpo médio, com uma textura suave. Ao provar uma Pale Ale, você pode esperar um sabor maltado com notas de caramelo e torradas, equilibrado com um amargor moderado do lúpulo, que pode ter sabores florais, frutados ou terrosos.Essa cerveja é popular entre os amantes de cervejas artesanais que procuram uma experiência de sabor equilibrada, mas ainda assim com um pouco de amargor. É uma cerveja versátil que pode ser apreciada sozinha ou emparelhada com uma variedade de alimentos, desde carnes grelhadas até pratos picantes.',NULL,5.80,31.00,'Taça'),(2,2,'Abridor de Lata e Garrafa',38.60,NULL,'abridor de lata e garrafa 3.png','Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',NULL,NULL,NULL,NULL),(3,3,'Kit de Cerveja - Dia das Mães',60.00,NULL,'kits cervejas.png','Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',NULL,NULL,NULL,NULL),(4,1,'Brown Ale',24.90,NULL,'brown.png','Inspirada no raro estilo austríaco, a cerveja conquistou diversos prêmios internacionais. Ela tem uma coloração âmbar, conserva aroma intenso de malte que lembra biscoito e caramelo, com um toque cítrico. No paladar, o amargor é presente, com um final seco.',NULL,5.40,22.00,'Taça'),(5,2,'Boné',23.60,NULL,'bone.png','Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. ',NULL,NULL,NULL,NULL),(6,3,'Kit de Cerveja - Dia dos Pais',78.00,NULL,'kits cervejas.png','Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',NULL,NULL,NULL,NULL),(7,1,'Double Ipa',15.90,NULL,'double.png','Amargor, esta é a característica comum entre as diferentes IPAs. Este amargor vem do lúpulo, que, além do sabor peculiar, oferece quatro tipos de aromas diferentes: terroso, herbáceo, cítrico e frutado.',NULL,8.00,35.00,'Tulipa'),(8,2,'Caixa Térmmica.png',23.60,NULL,'caixa termica.png','Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',NULL,NULL,NULL,NULL),(9,3,'Kit Dia dos Namorados',54.90,NULL,'kits cervejas.png','Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',NULL,NULL,NULL,NULL),(10,1,'Pilsen',12.99,NULL,'american pale ale.png','Amargor. Esta é a característica comum entre as diferentes IPAs. Este amargor vem do lúpulo, que, além do sabor peculiar, oferece quatro tipos de aromas diferentes: terroso, herbáceo, cítrico e frutado.',NULL,5.10,20.00,'Copo Americano'),(11,2,'Camiseta Listrada',43.60,NULL,'camiseta listra 2.png','Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',NULL,NULL,NULL,NULL),(12,3,'Kit Festa Junina',75.40,NULL,'kits cervejas.png','Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `product` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-05-11 14:19:01
